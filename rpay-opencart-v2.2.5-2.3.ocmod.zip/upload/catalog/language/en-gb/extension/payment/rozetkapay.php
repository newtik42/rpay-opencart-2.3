<?php

$_['text_title'] = 'Pay via Visa|Mastercard|GooglePay|ApplePay (RozetkaPay)';
$_['button_pay'] = 'Go to payment';

$_['button_pay_holding'] = 'Go to payment (holding)';

$_['test_mode'] = 'Test mode';